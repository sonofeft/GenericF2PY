from fprog import add_2_ints, offset_int

my_sum = add_2_ints(2,3)
my_off = offset_int(11)

print('   my_sum=%i,  my_off=%i'%(my_sum, my_off))
