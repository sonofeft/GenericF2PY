"""
This example demonstrates the proper use of project: genericf2py
"""
from genericf2py.main import main

my_result = main()

